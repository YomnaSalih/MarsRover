const { default: test } = require("node:test");
const { required } = require("yargs");

const { moveForward, moveBackwards, turnLeft, turnRight } = require('./marsRover');

test('should move Forward on current heading', () => {
    const F1 = moveForward('f');
    expect(F1).toBe('(0, 1) North');
    const F2 = moveForward('fff');
    expect(F2).toBe('(0, 4) North');
});

test('should move Backwards on current heading', () => {
    const B1 = moveBackwards('b');
    expect(B1).toBe('(0, -1) North');
    const B2 = moveBackwards('bbb');
    expect(B2).toBe('(0, -4) North');
});

test('should rotate Left by 90 degrees', () => {
    const L1 = turnLeft('l');
    expect(L1).toBe('(0, 0) West');
    const L2 = turnLeft('lll');
    expect(L2).toBe('(0, 0) North');
});

test('should rotate Right by 90 degrees', () => {
    const R1 = turnRight('r');
    expect(R1).toBe('(0, 0) East');
    const R2 = turnRight('rrr');
    expect(R2).toBe('(0, 0) North');
});

