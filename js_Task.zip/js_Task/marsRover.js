let rover = {
    direction: "North",
    location: {x:0,y:0},
  }
  

  //Moving rover forward function
  function moveForward() {
    
    let loc_X = rover.location.x;
    let loc_Y = rover.location.y;
    let rover_Dir = rover.direction;
  
     if (rover_Dir === "North" && loc_Y <= 9) {
          rover.location.y += 1;
          return `(${rover.location.x}, ${rover.location.y}) ${rover_Dir} `;
      
     } else if (rover_Dir === "East" && loc_X < 9) {
          rover.location.x += 1;      
          return `(${rover.location.x}, ${rover.location.y}) ${rover_Dir} `;
      
     } else if (rover_Dir === "South" && loc_Y  < 9) {
          rover.location.y -= 1;
          return `(${rover.location.x}, ${rover.location.y}) ${rover_Dir} `;
      
     } else if (rover_Dir === "West" && loc_X < 9) {
          rover.location.x -= 1;      
          return `(${rover.location.x}, ${rover.location.y}) ${rover_Dir} `;
     }
  };

  
  //Moving rover backwards function
  function moveBackwards() {
      
      let loc_X = rover.location.x;
      let loc_Y = rover.location.y;
      let rover_Dir = rover.direction;
      
      if (rover_Dir === "North" && loc_Y <= 9) {
            rover.location.y -= 1;
            return `(${rover.location.x}, ${rover.location.y}) ${rover_Dir} `;
    
       } else if (rover_Dir === "East" && loc_X < 9) {
            rover.location.x -= 1;      
            return `(${rover.location.x}, ${rover.location.y}) ${rover_Dir} `;
       
       } else if (rover_Dir === "South" && loc_Y  < 9) {
            rover.location.y += 1;
            return `(${rover.location.x}, ${rover.location.y}) ${rover_Dir} `;
        
       } else if (rover_Dir === "West" && loc_X < 9) {
            rover.location.x += 1;      
            return `(${rover.location.x}, ${rover.location.y}) ${rover_Dir} `;
       }
    };

  
  //Turn left function
  function turnLeft(){
    switch (rover.direction) {
      case "North":
        rover.direction = "West";
        break;
      case "West":
        rover.direction = "South";
        break;
      case "South":
        rover.direction = "East";
        break;
      case "East":
        rover.direction = "North";
        break; 
    }   
    return `(${rover.location.x}, ${rover.location.y}) ${rover.direction}`;    
  }
  
  
  //Turn right function
  function turnRight(){
    switch (rover.direction) {
      case "North":
        rover.direction = "East";
        break;
      case "East":
        rover.direction = "South";
        break;
      case "South":
        rover.direction = "West";
        break;
      case "West":
        rover.direction = "North";
        break;      
    }   
    return `(${rover.location.x}, ${rover.location.y}) ${rover.direction} `;    
  }
  
  
  while(true){

      let str = window.prompt("Enter command: ");

      for(let i = 0; i < str.length; i++)
      {
        var name = str[i];
        switch(name)
        {
            case "f": console.log(moveForward());
            break;
            case "b": console.log(moveBackwards());
            break;
            case "l": console.log(turnLeft());
            break;
            case "r": console.log(turnRight());
            break;
        }
    }

      if (name == 's')
      break;
    
  }
  
  